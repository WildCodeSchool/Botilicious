'use strict';
module.exports = (sequelize, DataTypes) => {
  var modules = sequelize.define('modules', {
    name: DataTypes.TEXT,
    description: DataTypes.TEXT,
    apiurl: DataTypes.TEXT
  }, {
    classMethods: {
      associate: function(models) {
        // associations can be defined here
      }
    }
  });
  return modules;
};