'use strict';
module.exports = (sequelize, DataTypes) => {
  var categories = sequelize.define('categories', {
    // sequelize model:create --name categories --attributes "name:text"
    name: DataTypes.TEXT
  }, {
    classMethods: {
      associate: function(models) {
        // associations can be defined here
      }
    }
  });
  categories.belongsTo(modules, {through: 'category_has_module'});
  modules.belongsTo(categories, {through: 'category_has_module'});
  return categories;
};
